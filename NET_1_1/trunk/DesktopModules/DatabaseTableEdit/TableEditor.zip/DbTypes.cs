using System;
using System.Data;
using System.Collections;
using System.Text.RegularExpressions;

namespace TripleASP.SiteAdmin.TableEditorControl
{
	/// <summary>
	/// Summary description for DbTypes.
	/// </summary>
	public class DbTypes
	{
		private Hashtable SqlParamTypes;
		public DbTypes()
		{
			SqlParamTypes = Hashtable.Synchronized(new Hashtable());
    		SqlParamTypes.Add("int identity", SqlDbType.Int);
			SqlParamTypes.Add("bigint",SqlDbType.BigInt);
			SqlParamTypes.Add("binary",SqlDbType.Binary);
			SqlParamTypes.Add("bit",SqlDbType.Bit);
			SqlParamTypes.Add("char",SqlDbType.Char);
			SqlParamTypes.Add("datetime",SqlDbType.DateTime);
			SqlParamTypes.Add("decimal",SqlDbType.Decimal);
			SqlParamTypes.Add("float",SqlDbType.Float);
			SqlParamTypes.Add("image",SqlDbType.Image);
			SqlParamTypes.Add("int",SqlDbType.Int);
			SqlParamTypes.Add("money",SqlDbType.Money);
			SqlParamTypes.Add("nchar",SqlDbType.NChar);
			SqlParamTypes.Add("ntext",SqlDbType.NText);
			SqlParamTypes.Add("numeric",SqlDbType.Decimal);
			SqlParamTypes.Add("nvarchar",SqlDbType.NVarChar);
			SqlParamTypes.Add("real",SqlDbType.Real);
			SqlParamTypes.Add("smalldatetime",SqlDbType.SmallDateTime);
			SqlParamTypes.Add("smallint",SqlDbType.SmallInt);
			SqlParamTypes.Add("smallmoney",SqlDbType.SmallMoney);
			SqlParamTypes.Add("sql_variant",SqlDbType.Variant);
			SqlParamTypes.Add("text",SqlDbType.Text);
			SqlParamTypes.Add("timestamp",SqlDbType.Timestamp);
			SqlParamTypes.Add("tinyint",SqlDbType.TinyInt);
			SqlParamTypes.Add("uniqueidentifier",SqlDbType.UniqueIdentifier);
			SqlParamTypes.Add("varbinary",SqlDbType.VarBinary);
			SqlParamTypes.Add("varchar",SqlDbType.VarChar);
		}


		public void Dispose() 
		{
			Dispose(true);
			GC.SuppressFinalize(this); 
		}

		public SqlDbType GetDbType(string text)
		{
			if(SqlParamTypes.ContainsKey(text))
			{
				return (SqlDbType) SqlParamTypes[text];
			}
			else
			{
				if(Regex.IsMatch(text,"identity"))
				{
					if(SqlParamTypes.ContainsKey(Regex.Replace(text,"identity","").Trim()))
					{
						return (SqlDbType) SqlParamTypes[Regex.Replace(text,"identity","").Trim()];
					}
					else
					{
						return SqlDbType.Variant;
					}
				}
				else
				{
					return SqlDbType.Variant;
				}
			}
		
		}

		protected virtual void Dispose(bool disposing) 
		{
			if (disposing) 
			{
				// Free other state (managed objects).
			}
			// Free your own state (unmanaged objects).
			// Set large fields to null.
			SqlParamTypes = null;
		}
		~DbTypes()
		{
			// Simply call Dispose(false).
			Dispose (false);
		}
		public void Clear()
		{
			Dispose();
		}



	}
}
