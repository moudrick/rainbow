using System;

namespace TripleASP.SiteAdmin.TableEditorControl
{
	/// <summary>
	/// The RegexValidator class is a static class that holds a number of canned
	/// valdidation regular expressions
	/// </summary>
	public class RegexValidator
	{
		private RegexValidator()
		{

		}

		public static string StringLength(int start, int stop)
		{
			return @"^((\s|\S){" + start.ToString() +"," + stop.ToString() + "})$";
		}

		public static string DateTime
		{
			get
			{
				// orginal sch�tze USA
				//return @"^((((([13578])|(1[02]))[\-\/\s]?(([1-9])|([1-2][0-9])|(3[01])))|((([469])|(11))[\-\/\s]?(([1-9])|([1-2][0-9])|(30)))|(2[\-\/\s]?(([1-9])|([1-2][0-9]))))[\-\/\s]?\d{4})(\s((([1-9])|(1[0-2]))\:([0-5][0-9])((\s)|(\:([0-5][0-9])\s))([AM|PM|am|pm]{2,2})))?$";
				string r = "";
				r += @"^";
				r += @"(";
				r += @"(";
				r += @"(((0?[1-9])|([1-2][0-9])|(3[01]))[\.\-\/\s]?((0?[13578])|(1[02])))";
				r += @"|(((0?[1-9])|([1-2][0-9])|(30))[\.\-\/\s]?((0?[469])|(11)))";
				r += @"|(2[\.\-\/\s]?(([1-9])|([1-2][0-9])))";
				r += @")";
				r += @"[\.\-\/\s]?\d{4}";
				r += @")(\s)?";
				// jetzt die zeit 0 oder 1 mal
				r += @"(";
				// USA
				r += @"((([1-9])|(1[0-2]))\:([0-5][0-9])((\s)|(\:([0-5][0-9])\s))([AM|PM|am|pm]{2,2}))";
				// oder deutsch
				r += @"|(((0?[0-9])|(1[0-9])|(2[0-3]))\:([0-5][0-9])((\s)?|(\:([0-5][0-9])(\s)?)))";
				r += @")?";
				r += @"$";
				return r;
			}
		}

		public static string Time
		{
			get
			{
				return @"^((([1-9])|(1[0-2]))\:([0-5][0-9])((\s)|(\:([0-5][0-9])\s))([AM|PM|am|pm]{2,2}))$";
			}
		}

		public static string Bit
		{
			get
			{
				return @"^((true)|(True)|(TRUE)|(false)|(FALSE)|(False))$";
			}
		}

		public static string BigInt
		{
			get
			{
				return @"^((-([1-9]|[1-9]\d|[1-9]\d\d|[1-9]\d\d\d|[1-9]\d\d\d\d|[1-9]\d\d\d\d\d|[1-9]\d\d\d\d\d\d|[1-9]\d\d\d\d\d\d\d|[1-9]\d\d\d\d\d\d\d\d|[1-9]\d\d\d\d\d\d\d\d\d|[1-9]\d\d\d\d\d\d\d\d\d\d|[1-9]\d\d\d\d\d\d\d\d\d\d\d|[1-9]\d\d\d\d\d\d\d\d\d\d{1}\d\d|[1-9]\d\d\d\d\d\d\d\d\d\d\d\d\d|[1-9]\d\d\d\d\d\d\d\d\d\d\d\d\d\d|[1-9]\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d|[1-9]\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d|[1-9]\d\d\d\d\d\d{1}\d\d\d\d\d\d\d\d\d\d\d|[1-8]\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d|9[0-1]\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d|92[0-1]\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d|922[0-2]\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d|9223[0-2]\d\d\d\d\d\d\d\d\d\d\d\d{1}\d\d|92233[0-6]\d\d\d\d\d\d\d\d\d\d\d\d\d|922337[0-1]\d\d\d\d\d\d\d\d\d\d\d\d|92233720[0-2]\d\d\d\d\d\d\d\d\d\d|922337203[0-5]\d\d\d\d\d\d\d\d\d|9223372036[0-7]\d\d\d\d\d\d\d\d|92233720368[0-4]\d\d\d\d\d\d\d|922337203685[0-3]\d\d\d\d\d\d|9223372036854[0-6]\d\d\d\d{1}\d|92233720368547[0-6]\d\d\d\d|922337203685477[0-4]\d\d\d|9223372036854775[0-7]\d\d|922337203685477580[0-8]))|(([0-9]|[1-9]\d|[1-9]\d\d|[1-9]\d\d\d|[1-9]\d\d\d\d|[1-9]\d\d\d\d\d|[1-9]\d\d\d\d\d\d|[1-9]\d\d\d\d\d\d\d|[1-9]{1}\d\d\d\d\d\d\d\d|[1-9]\d\d\d\d\d\d\d\d\d|[1-9]\d\d\d\d\d\d\d\d\d\d|[1-9]\d\d\d\d\d\d\d\d\d\d\d|[1-9]\d\d\d\d\d{1}\d\d\d\d\d\d\d|[1-9]\d\d\d\d\d\d\d\d\d\d\d\d\d|[1-9]\d\d\d\d\d\d\d\d\d\d\d\d\d\d|[1-9]\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d|[1-9]\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d|[1-9]\d{1}\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d|[1-8]\d\d\d\d\d\d\d{1}\d\d\d\d\d\d\d\d\d\d\d|9[0-1]\d\d\d\d\d\d\d\d\d\d\d\d{1}\d\d\d\d\d|92[0-1]\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d|922[0-2]\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d|9223[0-2]\d\d\d\d\d\d\d{1}\d\d\d\d\d\d\d|92233[0-6]\d\d\d\d\d\d\d\d\d\d\d\d\d|922337[0-1]\d\d\d\d\d\d\d\d\d\d\d\d|92233720[0-2]\d\d\d\d\d\d\d\d\d\d|922337203[0-5]\d\d\d\d\d\d\d\d\d|9223372036[0-7]\d\d\d\d\d\d\d\d|92233720368[0-4]\d\d\d\d\d\d\d|922337203685[0-3]\d\d\d\d\d\d|9223372036854[0-6]\d\d\d\d\d|92233720368547[0-6]\d\d\d\d|922337203685477[0-4]\d\d\d|9223372036854775[0-7]\d\d|922337203685477580[0-7])))$";
			}
		}
	}
}
