Namespace ASPNetPortal

    Public Class EditUserDefinedTable
        Inherits ASPNetPortal.PortalModuleControl

        Protected WithEvents tblFields As System.Web.UI.WebControls.Table
        Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

        Private UserDefinedRowId As Integer = -1

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If Not (Request.Params("UserDefinedRowId") Is Nothing) Then
                UserDefinedRowId = Int32.Parse(Request.Params("UserDefinedRowId"))
            End If

            BuildTable()

            If Page.IsPostBack = False Then

                cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This Item ?');")

                If UserDefinedRowId <> -1 Then
                    Dim objUserDefinedTable As New UserDefinedTableDB()

                    Dim dr As SqlDataReader = objUserDefinedTable.GetSingleUserDefinedRow(UserDefinedRowId, ModuleId)
                    While dr.Read()
                        CType(tblFields.FindControl(dr("FieldTitle").ToString), TextBox).Text = dr("FieldValue").ToString
                    End While
                    dr.Close()
                Else
                    cmdDelete.Visible = False
                End If

                ' Store URL Referrer to return to portal
                ViewState("UrlReferrer") = Request.UrlReferrer.ToString()

            End If

        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click, cmdCancel.Click

            ' Redirect back to the portal home page
            Response.Redirect(CStr(ViewState("UrlReferrer")))

        End Sub

        Private Sub BuildTable()
            Dim objUserDefinedTable As New UserDefinedTableDB()
            Dim objRow As TableRow
            Dim objCell As TableCell
            Dim objTextBox As TextBox
            Dim objValidator As CompareValidator

            Dim dr As SqlDataReader = objUserDefinedTable.GetUserDefinedFields(ModuleId)
            While dr.Read
                objRow = New TableRow()

                objCell = New TableCell()
                objCell.Controls.Add(New LiteralControl(dr("FieldTitle").ToString & ":"))
                objCell.CssClass = "SubHead"
                objRow.Cells.Add(objCell)

                objCell = New TableCell()
                objTextBox = New TextBox()
                objTextBox.ID = dr("FieldTitle")
                objTextBox.Columns = "30"
                objTextBox.CssClass = "NormalTextBox"
                objCell.Controls.Add(objTextBox)

                objRow.Cells.Add(objCell)

                tblFields.Rows.Add(objRow)
            End While
            dr.Close()
        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click

            Dim objUserDefinedTable As New UserDefinedTableDB()
            Dim ValidInput As Boolean = True
            Dim strMessage As String

            Dim dr As SqlDataReader = objUserDefinedTable.GetUserDefinedFields(ModuleId)
            While dr.Read
                If Request.Form("_ctl0:" & dr("FieldTitle")) <> "" Then
                    Select Case dr("FieldType").ToString
                        Case "Int32"
                            Try : Dim obj As Integer = CInt(Request.Form("_ctl0:" & dr("FieldTitle")))
                            Catch
                                strMessage += "<br>" & dr("FieldTitle").ToString & " Must Contain A Valid Integer Value"
                                ValidInput = False
                            End Try
                        Case "Decimal"
                            Try : Dim obj As Decimal = CDec(Request.Form("_ctl0:" & dr("FieldTitle")))
                            Catch
                                strMessage += "<br>" & dr("FieldTitle").ToString & " Must Contain A Valid Decimal Value"
                                ValidInput = False
                            End Try
                        Case "DateTime"
                            Try : Dim obj As Date = CDate(Request.Form("_ctl0:" & dr("FieldTitle")))
                            Catch
                                strMessage += "<br>" & dr("FieldTitle").ToString & " Must Contain A Valid Date Value"
                                ValidInput = False
                            End Try
                        Case "Boolean"
                            Try : Dim obj As Boolean = CBool(Request.Form("_ctl0:" & dr("FieldTitle")))
                            Catch
                                strMessage += "<br>" & dr("FieldTitle").ToString & " Must Contain A True/False Value"
                                ValidInput = False
                            End Try
                    End Select
                End If
            End While
            dr.Close()

            If ValidInput Then
                If UserDefinedRowId = -1 Then
                    UserDefinedRowId = objUserDefinedTable.AddUserDefinedRow(ModuleId, UserDefinedRowId)
                End If

                dr = objUserDefinedTable.GetUserDefinedFields(ModuleId)
                While dr.Read
                    objUserDefinedTable.UpdateUserDefinedData(UserDefinedRowId, dr("UserDefinedFieldId"), Request.Form("_ctl0:" & dr("FieldTitle")))
                End While
                dr.Close()

                objUserDefinedTable.UpdateUserDefinedRow(UserDefinedRowId)

                Response.Redirect(ViewState("UrlReferrer"))
            Else
                lblMessage.Text = strMessage
            End If

        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelete.Click

            Dim objUserDefinedTable As New UserDefinedTableDB()

            objUserDefinedTable.DeleteUserDefinedRow(UserDefinedRowId)

            Response.Redirect(ViewState("UrlReferrer"))

        End Sub

    End Class

End Namespace