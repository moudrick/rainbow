IBuySpy Workshop ( http://65.174.86.217/ibuyspyworkshop )

User Defined Table Custom Module

The User Defined Table allows the portal administrator to create custom tables of 
information. The administrator can dynamically add as many fields as they require 
to a table. In addition they can specify the data types of the fields for validation. 
The order in which the fields are displayed can be controlled as well as the default 
sort order. Fields can be flagged as Hidden so that they do not appear in the table 
view but exist behind the scenes in the database. The main table view features 
dynamically sortable columns.

1. Open the package in WinZip
   - select Extract

   - Extract To: specify your root project folder ( ie. C:\ASPNETPortal )

   - Options: Overwrite Existing Files + Use Folder Names

2. Open your solution in VS.NET
   - add the new folder and files to your project:

   - ASPNETPortal
     - Components
       - UserDefinedTableDB.vb ( Add Existing Item... )
     - DesktopModules
       - UserDefinedTable ( Add New Folder... )
         - UserDefinedTable.ascx ( Add Existing Item... )
         - UserDefinedTable.ascx.vb ( Add Existing Item... )
         - EditUserDefinedTable.ascx ( Add Existing Item... )
         - EditUserDefinedTable.ascx.vb ( Add Existing Item... )
         - ManageUserDefinedTable.ascx ( Add Existing Item... )
         - ManageUserDefinedTable.ascx.vb ( Add Existing Item... )

   - Rebuild Solution

3. Execute the script.sql in Query Analyzer

