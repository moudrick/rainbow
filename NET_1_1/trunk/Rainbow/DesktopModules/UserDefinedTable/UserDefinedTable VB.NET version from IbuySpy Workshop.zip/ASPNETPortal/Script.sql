/* schema */
CREATE TABLE [dbo].[UserDefinedData] (
	[UserDefinedDataId] [int] IDENTITY (1, 1) NOT NULL ,
	[UserDefinedFieldId] [int] NOT NULL ,
	[UserDefinedRowId] [int] NOT NULL ,
	[FieldValue] [nvarchar] (2000) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[UserDefinedFields] (
	[UserDefinedFieldId] [int] IDENTITY (1, 1) NOT NULL ,
	[ModuleId] [int] NOT NULL ,
	[FieldTitle] [varchar] (50) NOT NULL ,
	[Visible] [bit] NOT NULL ,
	[FieldOrder] [int] NOT NULL ,
	[FieldType] [varchar] (20) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[UserDefinedRows] (
	[UserDefinedRowId] [int] IDENTITY (1, 1) NOT NULL ,
	[ModuleId] [int] NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[UserDefinedData] WITH NOCHECK ADD 
	CONSTRAINT [PK_UserDefinedData] PRIMARY KEY  CLUSTERED 
	(
		[UserDefinedDataId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[UserDefinedFields] WITH NOCHECK ADD 
	CONSTRAINT [PK_UserDefinedTable] PRIMARY KEY  CLUSTERED 
	(
		[UserDefinedFieldId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[UserDefinedRows] WITH NOCHECK ADD 
	CONSTRAINT [PK_UserDefinedRows] PRIMARY KEY  CLUSTERED 
	(
		[UserDefinedRowId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[UserDefinedFields] WITH NOCHECK ADD 
	CONSTRAINT [DF_UserDefinedFields_FieldOrder] DEFAULT (0) FOR [FieldOrder]
GO

ALTER TABLE [dbo].[UserDefinedData] ADD 
	CONSTRAINT [FK_UserDefinedData_UserDefinedFields] FOREIGN KEY 
	(
		[UserDefinedFieldId]
	) REFERENCES [dbo].[UserDefinedFields] (
		[UserDefinedFieldId]
	) NOT FOR REPLICATION ,
	CONSTRAINT [FK_UserDefinedData_UserDefinedRows] FOREIGN KEY 
	(
		[UserDefinedRowId]
	) REFERENCES [dbo].[UserDefinedRows] (
		[UserDefinedRowId]
	) NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[UserDefinedFields] ADD 
	CONSTRAINT [FK_UserDefinedFields_Modules] FOREIGN KEY 
	(
		[ModuleId]
	) REFERENCES [dbo].[Modules] (
		[ModuleID]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[UserDefinedRows] ADD 
	CONSTRAINT [FK_UserDefinedRows_Modules] FOREIGN KEY 
	(
		[ModuleId]
	) REFERENCES [dbo].[Modules] (
		[ModuleID]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

/* stored procedures */
drop procedure AddUserDefinedField
GO


create procedure AddUserDefinedField

@ModuleId     int,
@FieldTitle   varchar(50),
@Visible      bit,
@FieldType    varchar(20)

as

declare @FieldOrder int

select @FieldOrder = count(*) + 1
from   UserDefinedFields
where  ModuleId = @ModuleId

insert UserDefinedFields ( 
  ModuleId,
  FieldTitle,
  Visible,
  FieldType
)
values (
  @ModuleId,
  @FieldTitle,
  @Visible,
  @FieldType
)

return 1


GO
drop procedure AddUserDefinedRow
GO


create procedure AddUserDefinedRow

@ModuleId         int,
@UserDefinedRowId int OUTPUT

as

insert UserDefinedRows ( 
  ModuleId
)
values (
  @ModuleId
)

select @UserDefinedRowId = @@IDENTITY


GO
drop procedure DeleteUserDefinedField
GO


create procedure DeleteUserDefinedField

@UserDefinedFieldId    int 

as

delete 
from   UserDefinedData
where  UserDefinedFieldId = @UserDefinedFieldId

delete 
from   UserDefinedFields
where  UserDefinedFieldId = @UserDefinedFieldId

return 1

GO
drop procedure DeleteUserDefinedRow
GO


create procedure DeleteUserDefinedRow

@UserDefinedRowId    int 

as

delete 
from   UserDefinedData
where  UserDefinedRowId = @UserDefinedRowId

delete 
from   UserDefinedRows
where  UserDefinedRowId = @UserDefinedRowId

return 1

GO
drop procedure GetSingleUserDefinedField
GO


create procedure GetSingleUserDefinedField

@UserDefinedFieldId  int

as

select ModuleId,
       FieldTitle,
       Visible,
       FieldOrder
from   UserDefinedFields
where  UserDefinedFieldId = @UserDefinedFieldId

return 1


GO
drop procedure GetSingleUserDefinedRow
GO


create procedure GetSingleUserDefinedRow

@UserDefinedRowID   int,
@ModuleId           int

as

select UserDefinedFields.FieldTitle,
       UserDefinedData.FieldValue
from   UserDefinedData
inner join UserDefinedFields on UserDefinedData.UserDefinedFieldId = UserDefinedFields.UserDefinedFieldId
where  UserDefinedData.UserDefinedRowID = @UserDefinedRowID
and    UserDefinedFields.ModuleId = @ModuleId


GO
drop procedure GetUserDefinedFields
GO


create procedure GetUserDefinedFields

@ModuleId  int

as

select UserDefinedFieldId,
       FieldTitle,
       Visible,
       FieldType
from   UserDefinedFields
where  ModuleId = @ModuleId
order by FieldOrder

return 1


GO
drop procedure GetUserDefinedRows
GO


create procedure GetUserDefinedRows

@ModuleId    int 

as

select UserDefinedRows.UserDefinedRowId,
       UserDefinedFields.FieldTitle,
       UserDefinedData.FieldValue
from   UserDefinedRows
left outer join UserDefinedData on UserDefinedRows.UserDefinedRowId = UserDefinedData.UserDefinedRowId
inner join UserDefinedFields on UserDefinedData.UserDefinedFieldId = UserDefinedFields.UserDefinedFieldId 
where  UserDefinedRows.ModuleId = @ModuleId

return 1

GO
drop procedure UpdateUserDefinedData
GO


create procedure UpdateUserDefinedData

@UserDefinedRowId    int,
@UserDefinedFieldId  int,
@FieldValue          nvarchar(2000) = null

as

if @FieldValue is null
begin
  if exists ( select 1 from UserDefinedData where UserDefinedFieldId = @UserDefinedFieldId and UserDefinedRowId = @UserDefinedRowId )
  begin
    delete
    from UserDefinedData
    where UserDefinedFieldId = @UserDefinedFieldId
    and UserDefinedRowId = @UserDefinedRowId
  end
end
else
begin
  if not exists ( select 1 from UserDefinedData where UserDefinedFieldId = @UserDefinedFieldId and UserDefinedRowId = @UserDefinedRowId )
  begin
    insert UserDefinedData ( 
      UserDefinedFieldId,
      UserDefinedRowId,
      FieldValue
    )
    values (
      @UserDefinedFieldId,
      @UserDefinedRowId,
      @FieldValue
    )
  end
  else
  begin
    update UserDefinedData
    set    FieldValue = @FieldValue
    where UserDefinedFieldId = @UserDefinedFieldId
    and UserDefinedRowId = @UserDefinedRowId
  end
end

return 1

GO
drop procedure UpdateUserDefinedField
GO


create procedure UpdateUserDefinedField

@UserDefinedFieldId   int,
@FieldTitle           varchar(50),
@Visible              bit,
@FieldType            varchar(20)

as

update UserDefinedFields
set    FieldTitle = @FieldTitle,
       Visible = @Visible,
       FieldType = @FieldType
where  UserDefinedFieldId = @UserDefinedFieldId

return 1


GO
drop procedure UpdateUserDefinedFieldOrder
GO


create procedure UpdateUserDefinedFieldOrder

@UserDefinedFieldId  int,
@Direction           int

as

declare @ModuleId int
declare @FieldOrder int

select @ModuleId = ModuleId,
       @FieldOrder = FieldOrder
from   UserDefinedFields
where  UserDefinedFieldId = @UserDefinedFieldId

if (@Direction = -1 and @FieldOrder > 0) or (@Direction = 1 and @FieldOrder < ( select (count(*) - 1) from UserDefinedFields where ModuleId = @ModuleId ))
begin
  update UserDefinedFields
  set    FieldOrder = @FieldOrder
  where  ModuleId = @ModuleId
  and    FieldOrder = @FieldOrder + @Direction

  update UserDefinedFields
  set    FieldOrder = @FieldOrder + @Direction
  where  UserDefinedFieldId = @UserDefinedFieldId
end

return 1


GO
drop procedure UpdateUserDefinedRow
GO


create procedure UpdateUserDefinedRow

@UserDefinedRowId int

as

if not exists ( select 1 from UserDefinedData where UserDefinedRowId = @UserDefinedRowId )
begin
  delete
  from   UserDefinedRows
  where  userDefinedRowId = @UserDefinedRowId
end

GO

/* data */
insert into ModuleDefinitions ( FriendlyName, DesktopSrc, MobileSrc, AdminOrder, EditSrc, Secure ) 
values ( 'User Defined Table', 'DesktopModules/UserDefinedTable/UserDefinedTable.ascx', NULL, NULL, 'DesktopModules/UserDefinedTable/EditUserDefinedTable.ascx', 1 )
GO

insert into ModuleDefinitions ( FriendlyName, DesktopSrc, MobileSrc, AdminOrder, EditSrc, Secure ) 
values ( 'Manage UDT', NULL, NULL, NULL, 'DesktopModules/UserDefinedTable/ManageUserDefinedTable.ascx', 1 )
GO
