using System;
using System.Reflection;
using System.Configuration;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.ComponentModel;
using System.Text.RegularExpressions;
using TripleASP.SiteAdmin.TableEditorControl;


namespace TripleASP.SiteAdmin.TableEditorControl
{
	/// <summary>
	/// Summary description for TableEditor.
	/// </summary>
	/// 
	[
		Description("The TripleASP.Net TableEditor will allow you to instantly edit almost any SqlServer Table"),
		DefaultProperty("Table"),
		Designer(typeof(TableEditorControlDesigner)),
		ToolboxData("<{0}:TableEditor runat=server></{0}:TableEditor>")
	]
	public class TableEditor : DataGrid
	{
		#region Properties

		private string _connectionstring;
		private string _configconnectionstring;
		private string _table;
		private string _errormessage;
		private bool isEditing = false;
		private DataTable dt;
		private DataTable columninfo;
		private string primarykey;
		private int _maxstringlength = -1;
		private bool _allowediting = true;
		private bool _allowdeleting = true;


		[
			Browsable(true),
			Description("Sets the max legth for a each column"),
			Category("TableEditor")
		]
		public int MaxStringLength
		{
			get { return _maxstringlength; }
			set { _maxstringlength = value;}
		}
		[
			Browsable(true),
			Description("Gets connectionstring from web.config file"),
			Category("TableEditor")
		]
		public string ConfigConnectionString
		{
			get { return _configconnectionstring;}
			set { _configconnectionstring = value;}			
		}
		[
			Browsable(true),
			Description("Sets the connectionstring"),
			Category("TableEditor")
		]
		public string ConnectionString
		{
			get	{ return _connectionstring;}
			set	{ _connectionstring = value;}
		}

		[
			Browsable(true),
			Description("Name of table to edit"),
			Category("TableEditor")
		]
		public string Table
		{
			get {return _table;}
			set {_table = value;}
		}
		[
			DefaultValue("true"),
			Browsable(true),
			Description("Name of table to edit"),
			Category("TableEditor")
		]
		public bool AllowEditing
		{
			get {return _allowediting;}
			set {_allowediting = value;}
		}
		[
			DefaultValue("true"),
			Browsable(true),
			Description("Name of table to edit"),
			Category("TableEditor")
		]
		public bool AllowDeleting
		{
			get {return _allowdeleting;}
			set {_allowdeleting = value;}
		}

		#endregion

		#region control methods

		public TableEditor()
		{
			base.AutoGenerateColumns = false;
			base.AllowPaging = true;
			base.PageSize = 10;

			base.GridLines = GridLines.Horizontal;
			base.BorderColor = Color.Blue;
			base.BorderStyle = BorderStyle.Solid;
			base.BorderWidth = 1;
			base.ForeColor = Color.Black;
			base.CellPadding = 3;
			base.CellSpacing = 0;

			if (HttpContext.Current != null)
			{
				base.PagerStyle.Mode = PagerMode.NumericPages;
				base.HeaderStyle.Font.Bold = true;
				base.HeaderStyle.ForeColor = Color.White;
				base.HeaderStyle.BackColor = Color.Blue;
				base.HeaderStyle.BorderColor = Color.Blue;
				base.HeaderStyle.BorderWidth = 0;
				base.ItemStyle.BackColor = Color.White;
				base.AlternatingItemStyle.BackColor = Color.FromArgb(242,242,242);
			}
		}

		protected override void OnLoad(EventArgs e)
		{
			//If the _table value is set in code, it might not always be available to the control.
			//If the value is not available, try to get it from the viewstate. If value is still null in PreRender
			//it will be trapped their.
			if(_table == null)
			{
				_table = TableFromViewState;
			}

		}

		protected override void OnInit(EventArgs e)
		{
			if (HttpContext.Current != null)
			{
				if(_allowediting)
				{
					EditCommandColumn ecc = new EditCommandColumn();
					ecc.EditText = "Edit";
					ecc.CancelText = "Cancel";
					ecc.UpdateText = "Update";
					base.Columns.Add(ecc);
				}
				if(_allowdeleting)
				{
					ButtonColumn bc = new ButtonColumn();
					bc.Text = "Delete";
					bc.CommandName = "Delete";
					base.Columns.Add(bc);
				}
			}
					
		}

		protected override void Render(HtmlTextWriter writer)
		{
			
			if(_errormessage != null && _errormessage.Trim().Length > 0)
			{
				writer.WriteLine("<span style=\"COLOR: red\">" + _errormessage + "</span>");
			}
			if(_table != null)
			{
				base.Render(writer);
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			if(_table != null && CheckConnectionString == true)
			{				
				if(_table != TableFromViewState)
				{
					Reset();
				}
				BindGrid();
				
				base.DataKeyField = PrimaryKeyFromViewState;
				base.DataSource = dt;
				base.DataBind();
				
				EditMode();
				
				TableFromViewState = _table;
			}
		}

		#endregion

		#region Data Methods

		private bool CheckConnectionString
		{
			get
			{
				if(_connectionstring == null)
				{
					if(_configconnectionstring == null)
					{
						return false;
					}
					else
					{
						try
						{
							_connectionstring = (string) ConfigurationSettings.AppSettings[_configconnectionstring];
						}
						catch(Exception ex)
						{
							return false;
						}
						return (_connectionstring != null);
					}
				}
				else
				{ return true;}
			}
		}


		void BindGrid() 
		{

			columninfo = ColumnInfoFromViewState;
			primarykey = PrimaryKeyFromViewState;
			if(columninfo == null || primarykey == null)
			{
				SqlDataReader pk = GetPrimaryKeyReader();
				int i = 0;
				while(pk.Read())
				{
					primarykey = pk["COLUMN_NAME"].ToString();
					PrimaryKeyFromViewState = primarykey;
					if(i !=0)
					{
						pk.Close();
						throw new Exception("Only single column primary keys are supported");
					}
					i++;
					HasPK = true;
				}
				pk.Close();
				if(HasPK)
				{
					columninfo = GetDataTable("sp_columns '" +  _table + "'"); //SqlHelper.ExecuteDataset(_connectionstring, CommandType.StoredProcedure, "sp_columns", new SqlParameter("@table_name", _table)).Tables[0];
					ColumnInfoFromViewState = columninfo;
				}
			}

		if(HasPK)
		{
				try
				{
					dt = GetDataTable("Select * From " + _table);
					
					BuildColumns();
					if(AddingNew)
					{
						AddNewRow();
					}
				}
				catch(SqlException ex)
				{
					AddError("SQLException Error: " + ex.Message);
					throw;
				}
				catch(Exception ex)
				{
					AddError("Exception Error: " + ex.Message);
					throw;
				}
			}
			else
			{
				AddError("The table " + _table + " does not have a PrimaryKey Set");
			}
		}

		private SqlDataReader GetPrimaryKeyReader()
		{
			if(_connectionstring != null && _table != null)
			{
				SqlCommand cmd = new SqlCommand("sp_pkeys '" +  _table + "'", new SqlConnection(_connectionstring));
				cmd.Connection.Open();
				return cmd.ExecuteReader(CommandBehavior.CloseConnection);
			}
			else
			{
				throw new Exception("ConnectionString(or ConfigConnectionString) and/or Table value was not set");
			}
		}

		private DataTable GetDataTable(string sql)
		{
			if(_connectionstring != null)
			{
				SqlCommand cmd = new SqlCommand(sql, new SqlConnection(_connectionstring));
				SqlDataAdapter sda = new SqlDataAdapter(cmd);
				DataTable dt = new DataTable();
				sda.Fill(dt);
				return dt;
			}
			else
			{
				throw new Exception("ConnectionString value was not set");
			}
		}

		private DataSet GetDataSet(string sql)
		{
			if(_connectionstring != null)
			{
				SqlCommand cmd = new SqlCommand(sql, new SqlConnection(_connectionstring));
				SqlDataAdapter sda = new SqlDataAdapter(cmd);
				DataSet ds = new DataSet();
				sda.Fill(ds);
				return ds;
			}
			else
			{
				throw new Exception("ConnectionString value was not set");
			}
		}

		#endregion

		#region DataGrid Commands

		protected override void OnItemCreated(DataGridItemEventArgs e)
		{

			//Make sure user wants to delete a record. Will fire
			//a javascript confirmation message when delete is checked.
			LinkButton myDeleteButton;
			switch(e.Item.ItemType)
			{
				case ListItemType.Item:
				case ListItemType.AlternatingItem:	
					if(_allowdeleting)
					{
						//if true, allowediting will return 1, if false, it will return 0
						myDeleteButton = (LinkButton) e.Item.Cells[Convert.ToInt32(_allowediting)].Controls[0];
						myDeleteButton.Attributes.Add("onclick", "return confirm('Are you Sure you want to delete this record?');");
					}
					break;
				case ListItemType.Pager:
					
					TableCell pager = (TableCell) e.Item.Controls[0];
					pager.HorizontalAlign = HorizontalAlign.Center;

					for (int i=0;i < pager.Controls.Count; i +=2)
					{
						try
						{
							
							LinkButton h = (LinkButton) pager.Controls[i];
							h.CausesValidation = true;
							h.Text = "[" + h.Text + "]";
							
						}
						catch
						{
							Label l = (Label) pager.Controls[i];
							l.Text = "Page " + l.Text;
							l.ForeColor = Color.Blue;
							l.Font.Bold = true;
							
						}
					}
					//If editing is not allowed, do not add a new row since the
					//EditItemTemplate will not be built.
					if(_allowediting)
					{
						pager.Controls.Add(new LiteralControl("&nbsp;&nbsp;"));
						LinkButton lb = new LinkButton();
						lb.Text = "Add New";
						lb.CommandName = "AddNew";
						lb.Click += new EventHandler(AddNew_Click);
					
						pager.Controls.Add(lb);
					}
					break;
			}
			base.OnItemCreated(e);

		}


		protected void AddNew_Click(Object sender, EventArgs e) 
		{
			CheckIsEditing("");
			if (!isEditing) 
			{
				// set the flag so we know to do an insert at Update time
				AddingNew = true;
			}
		}

		private void AddNewRow()
		{
			object[] rowValues = new object[dt.Columns.Count];
			for(int i = 0; i == dt.Columns.Count; i++)
			{
				rowValues[i] = "";
			}

			dt.Rows.Add(rowValues);

			// figure out the EditItemIndex, last record on last page
			int recordCount = dt.Rows.Count;
			if (recordCount > 1)
			{
				recordCount--;
			}
			else
			{
				recordCount = 0;
			}
			base.CurrentPageIndex = recordCount/base.PageSize;
			base.EditItemIndex = recordCount%base.PageSize;
		}

		protected override void OnItemCommand(DataGridCommandEventArgs e) 
		{
			HttpContext.Current.Trace.Warn("OnItemCommand");
			// this event fires prior to all of the other commands
			// use it to provide a more graceful transition out of edit mode
			CheckIsEditing(e.CommandName);
			base.OnItemCommand(e);
		}


		protected void CheckIsEditing(string commandName) 
		{
			if (base.EditItemIndex != -1) 
			{
				// we are currently editing a row
				if (commandName != "Cancel" && commandName != "Update" && commandName != "AddNew") 
				{
					// user's edit changes (if any) will not be committed
					AddError("Your changes have not been saved yet.  Please press update to save your changes, or cancel to discard your changes, before selecting another item.");
					isEditing = true;
				}
			}
		}


		protected override void OnEditCommand(DataGridCommandEventArgs e) 
		{
			// turn on editing for the selected row
			if (!isEditing) 
			{
				base.EditItemIndex = e.Item.ItemIndex;
				base.OnEditCommand(e);
			}
		}

		private bool AllowColumnToBeEdited(string dbtype)
		{
			switch (dbtype.ToLower())
			{
				case "image":
				case "binary":
				case "varbinary":
					return false;
				default:
					return true;
			}
		}

		protected override void OnUpdateCommand(DataGridCommandEventArgs e) 
		{
			columninfo = ColumnInfoFromViewState;
			primarykey = PrimaryKeyFromViewState;
			if(columninfo == null || primarykey == null)
			{
				throw new Exception("Information Missing From ViewState!");
			}
			//Since we are adding our edit textboxes dynamically
			//we must retrieve our updated information using Request.Form
			//the uid + : will be the value asp.net adds to the front of each of
			//our form names
			string uid = e.Item.UniqueID.ToString() + ":";
			HttpContext context = HttpContext.Current;

			//Hashtable paramTypes = SqlParamTypes();
			DbTypes dbtypes = new DbTypes();
			
			if(!CheckConnectionString)
			{
				throw new Exception("ConnectionString value was not set");
			}
			SqlConnection myConnection = new SqlConnection(_connectionstring);
			SqlCommand UpdateCommand = new SqlCommand();
			UpdateCommand.Connection = myConnection;

			if (AddingNew)
			{
				StringBuilder sbInsert = new StringBuilder("Insert Into " + _table + "(");
				StringBuilder sbValues = new StringBuilder(" Values(");
				string primarykeytype = null;

				foreach(DataRow dr in columninfo.Rows)
				{
					string column = dr["COLUMN_NAME"].ToString();
					string dbtype = dr["Type_Name"].ToString();
					if(column != primarykey)
					{
						if(AllowColumnToBeEdited(dbtype))
						{
							sbInsert.Append(" " + column + ", ");
							sbValues.Append(" @" + column + ", ");
						}
					}
					else
					{
						//check to see if the primarykey is an identity column
						//if it is not an identity column, allow it to be added
						if(!Regex.IsMatch(dbtype,"identity"))
						{
							sbInsert.Append(" " + column + ", ");
							sbValues.Append(" @" + column + ", ");	
							primarykeytype = Regex.Replace(dbtype,"identity","").Trim();
						}
					}
				}

				//Remove extra ", "
				string insert = sbInsert.ToString().Substring(0, sbInsert.ToString().Length - 2) + ") ";
				string values = sbValues.ToString().Substring(0, sbValues.ToString().Length - 2) + ") ";
				UpdateCommand.CommandText = insert + " " + values;
				//if this value was set, then we have to get it from the Request.Form collection
				if(primarykeytype != null)
				{
					UpdateCommand.Parameters.Add("@" + primarykey, dbtypes.GetDbType(primarykeytype)).Value
						=  context.Request.Form[uid+primarykey];
				}
			}
			else
			{
				string primarykeytype = String.Empty;
				StringBuilder sbUpdate = 
					new StringBuilder("Update [" + _table + "] Set ");

				foreach(DataRow dr in columninfo.Rows)
				{
					string column = dr["COLUMN_NAME"].ToString();
					string dbtype = dr["Type_Name"].ToString();
					if(column != primarykey)
					{
						if(AllowColumnToBeEdited(dbtype))
						{
							sbUpdate.Append(" " + column + " = @" + column + ", ");
						}
					}
					else
					{
						primarykeytype = dbtype;
					}
				}
				//Remove extra ", "
				UpdateCommand.CommandText = sbUpdate.ToString().Substring(0, sbUpdate.ToString().Length - 2) 
					+ " Where " + primarykey + " = @" + primarykey;
				//Add the primary key parameter for the where section of the update command
				UpdateCommand.Parameters.Add("@" + primarykey, dbtypes.GetDbType(primarykeytype)).Value
					=  context.Request.Form[uid+primarykey];
			}
     
			foreach(DataRow dr in columninfo.Rows)
			{
				string column = dr["COLUMN_NAME"].ToString();
				string dbtype = dr["Type_Name"].ToString();
				
				if(AllowColumnToBeEdited(dbtype))
				{
					object formvalue = context.Request.Form[uid+column];
					if(formvalue == null || formvalue.ToString().Trim().Length == 0)
					{
						formvalue = System.DBNull.Value;
					}
					if(column != primarykey)
					{
						UpdateCommand.Parameters.Add("@" + column, dbtypes.GetDbType(dbtype)).Value 
							= formvalue;
					}
				}
			}

			//clear DbTypes
			dbtypes.Clear();

			// execute the command
			//Needs to be handled by SqlHelper
			try 
			{
				myConnection.Open();
				UpdateCommand.ExecuteNonQuery();
			}
			catch (Exception ex) 
			{
				AddError(ex.ToString());
			}
			finally 
			{
				myConnection.Close();
			}     
     
			if (AddingNew) 
			{
				base.CurrentPageIndex = 0;
				AddingNew = false;
			}

			base.EditItemIndex = -1;
			base.OnUpdateCommand(e);
		
		}


		protected override void OnCancelCommand(DataGridCommandEventArgs e) 
		{
			// cancel editing
			base.EditItemIndex = -1;
			AddingNew = false;
			base.OnCancelCommand(e);
		}


		protected override void OnDeleteCommand(DataGridCommandEventArgs e) 
		{
			if (!isEditing) 
			{
				try
				{
					object keyValue = (base.DataKeys[(int)e.Item.ItemIndex]);
					if(keyValue == null)
					{
						throw new Exception("Did not return a primary key");
					}
					string primarykey = PrimaryKeyFromViewState;
					string selectexp = "COLUMN_NAME = '" + primarykey + "'";
					DataRow[] dr = ColumnInfoFromViewState.Select(selectexp);
					DbTypes dbtypes = new DbTypes();
					if(CheckConnectionString){};
					SqlConnection myConnection = new SqlConnection(_connectionstring);
					SqlCommand UpdateCommand = new SqlCommand();
					UpdateCommand.Connection = myConnection;
					UpdateCommand.CommandText = "Delete From " + _table + " Where " + primarykey + " = @" + primarykey;
					UpdateCommand.Parameters.Add("@" + primarykey,dbtypes.GetDbType(dr[0]["Type_Name"].ToString())).Value = keyValue;

					dbtypes.Clear();

					try 
					{
						myConnection.Open();
						UpdateCommand.ExecuteNonQuery();
					}
					catch (Exception ex) 
					{
						AddError(ex.ToString());
					}
					finally 
					{
						myConnection.Close();
					} 
					base.CurrentPageIndex = 0;
					base.EditItemIndex = -1;
				}
				catch (Exception ex) 
				{
					AddError(ex.Message.ToString());
				}
			}
			base.OnDeleteCommand(e);
		}


		protected override void OnPageIndexChanged(DataGridPageChangedEventArgs e) 
		{
			// display a new page of data
			if (!isEditing) 
			{
				base.EditItemIndex = -1;
				base.CurrentPageIndex = e.NewPageIndex;
				//BindGrid();
			}
		}




		#endregion

		#region Helpers

		private void Reset()
		{
			AddingNew = false;
			base.DataKeyField = null;
			base.CurrentPageIndex = 0;
			base.EditItemIndex = -1;
		}

		protected void BuildColumns()
		{
			TemplateColumn gc;
			gc = new TemplateColumn();
			string editcolumn = columninfo.Rows[0]["COLUMN_NAME"].ToString();
			gc.HeaderText = editcolumn; //columns[0].ToString();
			gc.ItemTemplate = new GenericItemTemplateColumn(editcolumn,_maxstringlength);
			if(_allowediting)
			{
				gc.EditItemTemplate = new DataEntryFormItemTemplate(columninfo, primarykey);
			}
			base.Columns.Add(gc);

			for(int i = 1; i < columninfo.Rows.Count; i++)
			{
				string column = columninfo.Rows[i]["COLUMN_NAME"].ToString();
				gc = new TemplateColumn();
				gc.ItemTemplate = new GenericItemTemplateColumn(column,_maxstringlength);
				gc.HeaderText = column;
				base.Columns.Add(gc);
			}
		}
		protected void EditMode()
		{
			if(_allowdeleting)
			{
				base.Columns[1].Visible =  (base.EditItemIndex == -1);
			}
			for(int i = 2 + Convert.ToInt32(_allowdeleting); i < base.Columns.Count; i++)
			{
				base.Columns[i].Visible = (base.EditItemIndex == -1);
			}			
		}

		private void AddError(string text)
		{
			if(_errormessage == null)
			{
				_errormessage = text;
			}
			else
			{
				_errormessage += "<br>" + text;
			}
		}
		#endregion

		#region ViewState Items

		protected DataTable ColumnInfoFromViewState
		{
			get
			{
				return (DataTable) ViewState["columninfo" + _table];
			}
			set
			{
				ViewState["columninfo" + _table] = value;
			}
		
		}


		protected string PrimaryKeyFromViewState
		{
			get
			{
				return (string) ViewState["primarykey" + _table];
			}
			set
			{
				ViewState["primarykey" + _table] = value;
			}
		
		}

		protected string TableFromViewState
		{
			get
			{
				return (string) ViewState["table"];
			}
			set
			{
				ViewState["table"] = value;
			}
		
		}

		protected bool AddingNew 
		{
			get 
			{
				object o = ViewState["AddingNew"];
				return (o == null) ? false : (bool)o;
			}
			set 
			{
				ViewState["AddingNew"] = value;
			}
		}

		protected bool HasPK 
		{

			get 
			{
				object o = ViewState[_table + "HasPK"];
				return (o == null) ? false : (bool)o;
			}
			set 
			{
				ViewState[_table + "HasPK"] = value;
			}
		}


		#endregion

	}
}
